class HatsTable:
    def __init__(self, conn):
        self.conn = conn

    def insert(self, hat):
        self.conn.execute("""
            INSERT INTO hats (id, topping, supplier, quantity) VALUES (?,?,?,?) 
            """, [hat.getId(), hat.getTopping(), hat.getSupplier(), hat.getQuantity()])
        self.conn.commit()

    def findTheSupplier(self, topping_, supT):
        topping_ = topping_.split('\n')[0]
        allTable = self.conn.cursor()
        allTable.execute("""
                SELECT id, supplier, quantity FROM hats WHERE topping = ? ORDER BY supplier
            """, [topping_])
        theHatInfo = allTable.fetchone()
        hatsId = int(theHatInfo[0])
        hatsSup = int(theHatInfo[1])
        hatsQua = int(theHatInfo[2])
        cur2 = self.conn.cursor()
        cur2.execute("""
            UPDATE hats SET quantity = quantity - 1 WHERE id = ?
        """, [hatsId])
        self.conn.commit()
        if hatsQua == 0:
            cur3 = self.conn.cursor()
            cur3.execute("""
                DELETE FROM hats WHERE id = ?
            """, [hatsId,])
            self.conn.commit()

        return [hatsId, supT.bringTheSupplier(hatsSup)]





class SupplierTable:
    def __init__(self, conn):
        self.conn = conn

    def insert(self, supplier):
        self.conn.execute(""" 
            INSERT INTO suppliers(id, name) VALUES (?, ?)
                          """, [supplier.getId(), supplier.getName()])
        self.conn.commit()

    def bringTheSupplier(self, supId):
        cursor = self.conn.cursor()
        cursor.execute("""
                SELECT name FROM suppliers WHERE id = ?
                       """, [supId])
        supName = cursor.fetchone()
        return supName[0]



class OrdersTable:
    def __init__(self, conn):
        self.conn = conn

    def insert(self, order):
        self.conn.execute("""
            INSERT INTO orders(id, location, hat) VALUES (?,?,?)
                          """, [order.getId(), order.getLocation(), order.getHat()])
        self.conn.commit()
