import sqlite3
import atexit


from DAO import *


class Repository:
    def __init__(self):
        self.conn = sqlite3.connect('database.db')
        self.hats = HatsTable(self.conn)
        self.orders = OrdersTable(self.conn)
        self.suppliers = SupplierTable(self.conn)
        self.createTables()

    def close(self):
        self.conn.commit()
        self.conn.close()

    def createTables(self):
        self.conn.executescript("""
            CREATE TABLE suppliers(
                id  INTEGER PRIMARY KEY,
                name STRING NOT NULL
            );
            CREATE TABLE hats(
                id  INTEGER PRIMARY KEY,
                topping STRING  NOT NULL,
                supplier INTEGER REFERENCES suppliers(id),
                quantity INTEGER NOT NULL
            );
            CREATE TABLE orders(
                id  INTEGER PRIMARY KEY,
                location STRING NOT NULL,
                hat INTEGER REFERENCES hats(id)
            );
        """)



repo = Repository()
atexit.register(repo.close())