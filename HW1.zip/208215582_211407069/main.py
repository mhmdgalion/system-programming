import sys
import DTO
import os

if os.path.exists('database.db'):
    os.remove('database.db')

from Repository import repo

def ordersToDo(lines):
    orderId = 1
    counter = 0
    output = ""
    for line in lines:
        thisLine = line.split(',')
        location = thisLine[0]
        topping = thisLine[1].split('\n')[0]
        theHatsSupp = repo.hats.findTheSupplier(topping, repo.suppliers)
        supName = theHatsSupp[1]
        newOrder = DTO.Orders(orderId,location, theHatsSupp[0])
        repo.orders.insert(newOrder)
        orderId += 1
        output += topping + "," +supName + "," + location
        if len(lines)-1 != counter:
                output += "\n"
        counter += 1
    return output



def configToDo(lines):
    numbersOfStuff = lines[0].split(',')
    numOfHatTypes = int(numbersOfStuff[0].split('\n')[0])
    numberOfSuppliers = int(numbersOfStuff[1].split('\n')[0])

    for i in range(1, numOfHatTypes+1):
        thisLine = lines[i].split('\n')[0].split(',')
        currHat = DTO.Hats(thisLine[0], thisLine[1], thisLine[2], thisLine[3])
        repo.hats.insert(currHat)

    for i in range(numOfHatTypes+1, numberOfSuppliers+numOfHatTypes+1):
        thisLine = lines[i].split('\n')[0].split(',')
        currSup = DTO.Supplier(thisLine[0], thisLine[1])
        repo.suppliers.insert(currSup)



def main(configFile, ordersFile):
    with open(configFile, 'r') as config:
        lines = config.readlines()
        configToDo(lines)
    with open(ordersFile, 'r') as orders:
        lines = orders.readlines()
        result = ordersToDo(lines)
        txtBox = open("output.txt", "w")
        txtBox.write(result)

if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])



